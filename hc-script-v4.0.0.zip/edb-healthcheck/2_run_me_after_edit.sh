#!/bin/bash

# add some colors
Color_Off='\033[0m'       # Text Reset
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow
Cyan='\033[0;36m'         # Cyan

# check & adjust permissions, exit on error
chown -R $(whoami):$(whoami) ./* > /dev/null 2>&1
if [ "${?}" -ne "0" ]; then
    /usr/bin/echo -e "${Red}ERROR${Color_Off} - Permission denied on some files and directories"
    /usr/bin/echo -e "Please adjust files and directories permissions and re-run the script"
    exit 1
fi

sed -i 's/\r$//' ./script_pm/params
sed -i 's/\r$//' ./script_pm/main
. ./script_pm/params
. ./script_pm/main

# mandatory to run first
init ${PASS_ARGS}

# os-only, check_barman, efm-witness, check-pgpool
if [ "${OS_ONLY}" = "true" ] || [ "${CHECK_BARMAN}" = "true" ] \
|| [ "${EFM_WITNESS}" = "true" ] || [ "${CHECK_PGPOOL}" = "true" ]; then
    check_dir_os ${PASS_ARGS}
    if [ "${EFM_WITNESS}" = "true" ]; then
        check_dir_efm ${PASS_ARGS}
    fi
    if [ "${CHECK_PGPOOL}" = "true" ]; then
        check_dir_pgpool ${PASS_ARGS}
    fi
    check_dir_handler ${PASS_ARGS}
    prereq_check_os ${PASS_ARGS}
    if [ "${EFM_WITNESS}" = "true" ]; then
        prereq_check_efm ${PASS_ARGS}
    fi
    if [ "${CHECK_BARMAN}" = "true" ]; then
        prereq_check_barman ${PASS_ARGS}
    fi
    if [ "${CHECK_PGPOOL}" = "true" ]; then
        prereq_check_pgpool ${PASS_ARGS}
    fi
    prereq_check_handler ${PASS_ARGS}
    prereq_check_summary ${PASS_ARGS}
    prompt_os_pass ${PASS_ARGS}
    collect_os_info ${PASS_ARGS}
    if [ "${EFM_WITNESS}" = "true" ]; then
        collect_efm_info ${PASS_ARGS}
        collect_efm_logs ${PASS_ARGS}
    fi
    if [ "${CHECK_BARMAN}" = "true" ]; then
        collect_barman_info ${PASS_ARGS}
    fi
    if [ "${CHECK_PGPOOL}" = "true" ]; then
        collect_pgpool_info ${PASS_ARGS}
        collect_pgpool_logs ${PASS_ARGS}
    fi
    verify_output ${PASS_ARGS}
    summarize ${PASS_ARGS}
    echo ""
    exit 0
fi

# run the functions - default: no option
check_dir_os ${PASS_ARGS}
check_dir_db ${PASS_ARGS}
check_dir_efm ${PASS_ARGS}
check_dir_handler ${PASS_ARGS}
prereq_check_os ${PASS_ARGS}
prereq_check_db ${PASS_ARGS}
prereq_check_efm ${PASS_ARGS}
prereq_check_handler ${PASS_ARGS}
prereq_check_summary ${PASS_ARGS}
prompt_os_pass ${PASS_ARGS}
prompt_db_pass ${PASS_ARGS}
collect_os_info ${PASS_ARGS}
collect_db_info ${PASS_ARGS}
collect_db_config ${PASS_ARGS}
run_hc_script ${PASS_ARGS}
collect_db_logs ${PASS_ARGS}
collect_efm_info ${PASS_ARGS}
collect_efm_logs ${PASS_ARGS}
verify_output ${PASS_ARGS}
summarize ${PASS_ARGS}

echo ""
