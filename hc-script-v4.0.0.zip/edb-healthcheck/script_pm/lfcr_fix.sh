#!/bin/bash

# NOTE: Run this script if you encounter LFCR error when running EDB-HealthCheck script
# Change your working directory inside 'script_pm', then run this script,
# so the relative path work correctly

# LFCR (Line Feed Carriage Return) Fix
sed -i 's/\r$//' ./main
sed -i 's/\r$//' ./params
sed -i 's/\r$//' ../1_edit_me_before_run.txt
sed -i 's/\r$//' ../2_run_me_after_edit.sh

# NOTE: If you encounter LFCR error when running this script,
# manually run the following command:
# sed -i 's/\r$//' ./lfcr_fix.sh
