SELECT pg_is_in_recovery();

-- Only available on PG 9.6+
SELECT * FROM pg_stat_wal_receiver
WHERE EXISTS (
    SELECT 1 FROM pg_class WHERE relname = 'pg_stat_wal_receiver'
);

SELECT * FROM pg_stat_replication;
