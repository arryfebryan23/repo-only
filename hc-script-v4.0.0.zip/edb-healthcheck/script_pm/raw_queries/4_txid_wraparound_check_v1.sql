SELECT datname, age(datfrozenxid) FROM pg_database;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass as table_name, 
  age(c.relfrozenxid), 
  pg_size_pretty(
    pg_total_relation_size(c.oid)
  ) as size 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  relkind IN ('r', 't', 'm') 
  AND n.nspname NOT IN ('pg_toast') 
  AND age(c.relfrozenxid) > 1100000000 
ORDER BY 
  3 DESC;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass as table_name, 
  c.reloptions 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  c.reloptions <> '{}';
