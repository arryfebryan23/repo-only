SELECT * FROM pg_file_settings;

SELECT * FROM pg_hba_file_rules;
