select * from pg_replication_slots;

SELECT 
  client_addr, 
  state, 
  pg_xlog_location_diff(sent_location, write_location) as write_lag, 
  pg_xlog_location_diff(sent_location, flush_location) as flush_lag 
FROM 
  pg_stat_replication;
