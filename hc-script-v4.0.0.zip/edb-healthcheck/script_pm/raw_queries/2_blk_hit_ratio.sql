SELECT 
  (
    blks_hit * 100 /(blks_hit + blks_read)
  ):: numeric as hit_ratio 
FROM 
  pg_stat_database 
WHERE 
  datname = current_database();
