select 
  datname database_name, 
  blk_read_time time_spent_in_reading_data_block, 
  blk_write_time time_spent_in_writing_data_block 
from 
  pg_stat_database;
