select 
  datname database_name, 
  xact_commit :: float /(
    case when (xact_commit + xact_rollback)= 0 then null else (xact_commit + xact_rollback) end
  ) fraction_txn_committed, 
  xact_rollback :: float /(
    case when (xact_commit + xact_rollback)= 0 then null else (xact_commit + xact_rollback) end
  ) fraction_txn_rolledback 
from 
  pg_stat_database;
