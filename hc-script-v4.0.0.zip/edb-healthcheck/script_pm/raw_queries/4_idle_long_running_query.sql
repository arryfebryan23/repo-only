SELECT 
  now() - query_start as "runtime", 
  backend_start, 
  pid, 
  usename, 
  datname, 
  client_addr, 
  client_port, 
  state, 
  query 
FROM 
  pg_stat_activity 
WHERE 
  now() - query_start > '30 minutes' :: interval 
  and state = 'idle' 
ORDER BY 
  runtime DESC;
