select 
  schemaname, 
  relname, 
  n_tup_ins num_rows_inserted, 
  n_tup_upd num_rows_updated, 
  n_tup_del num_rows_deleted 
from 
  pg_stat_all_tables 
order by 
  (n_tup_ins + n_tup_upd + n_tup_del) desc 
limit 
  10;
