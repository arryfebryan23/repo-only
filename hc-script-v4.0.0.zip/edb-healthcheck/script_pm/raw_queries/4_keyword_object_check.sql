select 
  t1.SchemaName, 
  t1.ObjectName, 
  t1.ObjectOwner, 
  t1.ObjectType 
from 
  (
    select 
      nsp.nspname as SchemaName, 
      cls.relname as ObjectName, 
      rol.rolname as ObjectOwner, 
      case cls.relkind when 'r' then 'TABLE' when 'm' then 'MATERIALIZED_VIEW' when 'i' then 'INDEX' when 'S' then 'SEQUENCE' when 'v' then 'VIEW' when 'c' then 'TYPE' else cls.relkind :: text end as ObjectType 
    from 
      pg_class cls 
      join pg_roles rol on rol.oid = cls.relowner 
      join pg_namespace nsp on nsp.oid = cls.relnamespace 
    where 
      nsp.nspname not in (
        'information_schema', 'pg_catalog', 
        'sys'
      ) 
      and nsp.nspname not like 'pg_toast%' 
      and nsp.nspname not like 'dbms%' 
      and nsp.nspname not like 'utl%' 
    order by 
      nsp.nspname, 
      cls.relname
  ) as t1 
  join pg_get_keywords() keyword on t1.objectname = keyword.word;
