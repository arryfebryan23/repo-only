select 
  pgtabstat.relname, 
  pgtabstat.schemaname, 
  pgcls.reltuples row_count, 
  pgtabstat.n_live_tup live_rows, 
  pgtabstat.n_dead_tup dead_rows, 
  pgtabstat.n_tup_upd, 
  pgtabstat.n_tup_del, 
  pgtabstat.n_tup_hot_upd, 
  pgtabstat.last_vacuum :: date, 
  pgtabstat.last_autovacuum :: date 
from 
  pg_class pgcls 
  join pg_namespace pgnpsc on pgnpsc.oid = pgcls.relnamespace 
  join pg_stat_user_tables pgtabstat on pgtabstat.relname = pgcls.relname 
  and pgnpsc.nspname = pgtabstat.schemaname 
where 
  pgtabstat.n_dead_tup > 500;
