SELECT 
  (
    xact_commit :: float * 100 /(xact_commit + xact_rollback)
  ):: numeric as successful_xact_ratio 
FROM 
  pg_stat_database 
WHERE 
  datname = current_database();
