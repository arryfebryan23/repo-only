select 
  n.nspname as schema, 
  c.relname as table 
from 
  pg_class c 
  join pg_namespace n on n.oid = c.relnamespace 
where 
  c.relkind = 'r' 
  and not exists (
    select 
      1 
    from 
      pg_constraint con 
    where 
      con.conrelid = c.oid 
      and con.contype in ('p', 'u')
  ) 
  and n.nspname not in (
    'pg_catalog', 'sys', 'dbo', 'information_schema'
  );
