select 
  schemaname, 
  relname, 
  n_live_tup, 
  n_dead_tup,
  round(n_dead_tup::numeric / nullif(n_live_tup, 0) * 100, 2) as dead_tup_pct
from 
  pg_stat_user_tables 
where 
  n_live_tup > 0
  and n_dead_tup > n_live_tup * 0.20
order by 
  n_dead_tup desc;
