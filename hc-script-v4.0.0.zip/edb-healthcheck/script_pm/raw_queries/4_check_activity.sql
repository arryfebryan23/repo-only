select 
  usename, 
  client_addr, 
  state, 
  count(usename) 
from 
  pg_stat_activity 
group by 
  1, 
  2, 
  3 
order by 
  count(usename) DESC;

select * from pg_stat_activity;
