select * from information_schema.foreign_data_wrappers;
select * from information_schema.foreign_data_wrapper_options;

select * from information_schema.foreign_servers;
select * from information_schema.foreign_server_options;

select * from information_schema.foreign_tables;
select * from information_schema.foreign_table_options;
