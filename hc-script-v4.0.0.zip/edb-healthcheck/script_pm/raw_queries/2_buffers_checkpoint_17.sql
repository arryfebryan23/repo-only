WITH 
  io_stats AS (
    SELECT 
      backend_type, 
      writes AS shared_blks_written 
    from 
      pg_stat_io 
    where 
      context = 'normal' 
      and backend_type in (
        'background writer', 'checkpointer', 
        'client backend'
      )
  ) 
SELECT 
  100 * SUM(
    CASE WHEN backend_type = 'background writer' THEN shared_blks_written ELSE 0 END
  ) / NULLIF(
    SUM(shared_blks_written), 
    0
  ) AS bgwriter_pct_17, 
  100 * SUM(
    CASE WHEN backend_type = 'checkpointer' THEN shared_blks_written ELSE 0 END
  ) / NULLIF(
    SUM(shared_blks_written), 
    0
  ) AS checkpoint_pct_17, 
  100 * SUM(
    CASE WHEN backend_type = 'client backend' THEN shared_blks_written ELSE 0 END
  ) / NULLIF(
    SUM(shared_blks_written), 
    0
  ) AS backend_pct_17 
FROM 
  io_stats;
