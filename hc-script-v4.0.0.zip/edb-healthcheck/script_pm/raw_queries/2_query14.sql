select 
  relname, 
  n_tup_upd, 
  n_tup_del, 
  n_tup_hot_upd, 
  last_vacuum, 
  last_autovacuum 
from 
  pg_stat_all_tables 
where 
  n_dead_tup /(
    case when n_live_tup = 0 then 1 else n_live_tup end
  )> 0.2;
