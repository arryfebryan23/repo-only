SELECT 
  (
    SELECT 
      coalesce(
        max(
          age(backend_xmin)
        ), 
        0
      ) 
    FROM 
      pg_stat_activity
  ) AS oldest_xact_age, 
  (
    SELECT 
      coalesce(
        max(
          age(backend_xmin)
        ), 
        0
      ) 
    FROM 
      pg_stat_replication
  ) AS oldest_standby_xact_age, 
  (
    SELECT 
      coalesce(
        max(
          age(transaction)
        ), 
        0
      ) 
    FROM 
      pg_prepared_xacts
  ) AS oldest_prepared_xact_age, 
  (
    SELECT 
      greatest(
        coalesce(
          max(
            age(xmin)
          ), 
          0
        ), 
        coalesce(
          max(
            age(catalog_xmin)
          ), 
          0
        )
      ) 
    FROM 
      pg_replication_slots
  ) AS oldest_replication_slot_age;

SELECT 
  pid, 
  age(backend_xmin), 
  datname, 
  usename, 
  application_name, 
  client_addr, 
  state, 
  query 
FROM 
  pg_stat_activity 
WHERE 
  age(backend_xmin) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  2 DESC;

SELECT 
  pid, 
  age(backend_xmin), 
  usename, 
  application_name, 
  client_addr, 
  state 
FROM 
  pg_stat_replication 
WHERE 
  age(backend_xmin) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  2 DESC;

SELECT 
  transaction, 
  gid, 
  age(transaction), 
  prepared, 
  owner, 
  database 
FROM 
  pg_prepared_xacts 
WHERE 
  age(transaction) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  3 DESC;

SELECT 
  slot_name, 
  age(xmin), 
  slot_type, 
  database, 
  active 
FROM 
  pg_replication_slots 
WHERE 
  greatest(
    age(xmin), 
    age(catalog_xmin)
  ) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  2 DESC;

SELECT 
  datname, 
  age(datfrozenxid) 
FROM 
  pg_database 
WHERE 
  age(datfrozenxid) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  2 DESC;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass AS table_name, 
  age(c.relfrozenxid) AS age, 
  pg_size_pretty(
    pg_total_relation_size(c.oid)
  ) AS table_total_size 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  c.relkind IN ('r', 'm', 't') 
  AND age(c.relfrozenxid) > current_setting('autovacuum_freeze_max_age'):: bigint 
ORDER BY 
  3 DESC, 
  pg_total_relation_size(c.oid) DESC;

SELECT 
  2 ^ 31 - max(x.age) AS txid_left 
FROM 
  (
    SELECT 
      coalesce(
        max(
          age(backend_xmin)
        ), 
        0
      ) AS age 
    FROM 
      pg_stat_activity 
    UNION ALL 
    SELECT 
      coalesce(
        max(
          age(backend_xmin)
        ), 
        0
      ) AS age 
    FROM 
      pg_stat_replication 
    UNION ALL 
    SELECT 
      coalesce(
        max(
          age(transaction)
        ), 
        0
      ) AS age 
    FROM 
      pg_prepared_xacts 
    UNION ALL 
    SELECT 
      coalesce(
        max(
          age(xmin)
        ), 
        0
      ) AS age 
    FROM 
      pg_replication_slots 
    UNION ALL 
    SELECT 
      coalesce(
        max(
          age(catalog_xmin)
        ), 
        0
      ) AS age 
    FROM 
      pg_replication_slots
  ) x;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass AS table_name, 
  c.relfrozenxid, 
  current_setting('autovacuum_freeze_max_age'):: bigint - age(c.relfrozenxid) AS xid_left_to_antifreeze, 
  pg_size_pretty(
    pg_total_relation_size(c.oid)
  ) AS table_total_size 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  c.relkind IN ('r', 'm', 't') 
ORDER BY 
  4 ASC, 
  pg_total_relation_size(c.oid);
