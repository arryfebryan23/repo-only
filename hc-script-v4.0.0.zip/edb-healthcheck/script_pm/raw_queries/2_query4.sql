select 
  datname database_name, 
  tup_inserted rows_inserted, 
  tup_updated rows_updated, 
  tup_deleted rows_deleted 
from 
  pg_stat_database;
