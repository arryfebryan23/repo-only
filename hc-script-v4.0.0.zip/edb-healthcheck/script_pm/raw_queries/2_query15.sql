WITH 
  x AS (
    SELECT 
      '"' || schemaname || '"' || '.' || '"' || tablename || '"' AS tbl 
    FROM 
      pg_tables
  ), 
  y AS (
    SELECT 
      ARRAY [
       tbl
             ,pg_size_pretty(pg_relation_size(tbl))
            ,pg_size_pretty(pg_relation_size(tbl, 'vm'))
            ,pg_size_pretty(pg_relation_size(tbl, 'fsm'))
            ,pg_size_pretty(pg_table_size(tbl))
            ,pg_size_pretty(pg_indexes_size(tbl))
            ,pg_size_pretty(pg_total_relation_size(tbl))
            ,pg_stat_get_live_tuples(tbl::regclass)::text
            ,pg_stat_get_dead_tuples(tbl::regclass)::text
            , '-----------------------------'
          ] AS val, 
      ARRAY [
             'relation_name'
             ,'core_relation_size'
            ,'visibility_map'
            ,'free_space_map'
            ,'table_size_incl_toast'
            ,'indexes_size'
            ,'total_size_incl_toast_and_indexes'
            ,'live_rows_in_text_representation'
            ,'dead_rows_in_text_representation'
            , '-----------------------------'
          ] AS name 
    FROM 
      x 
    order by 
      pg_total_relation_size(tbl)
  ) 
SELECT 
  unnest(name) AS what, 
  unnest(val) AS details 
FROM 
  y;
