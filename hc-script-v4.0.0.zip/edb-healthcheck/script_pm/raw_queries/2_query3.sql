select 
  datname database_name, 
  tup_returned :: float /(
    case when tup_fetched = 0 then null else tup_fetched end
  ) fraction_rows_returned 
from 
  pg_stat_database;
