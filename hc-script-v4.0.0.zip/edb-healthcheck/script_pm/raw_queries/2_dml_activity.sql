select 
  datname database_name, 
  tup_inserted rows_inserted, 
  tup_updated rows_inserted, 
  tup_deleted rows_inserted 
from 
  pg_stat_database;
