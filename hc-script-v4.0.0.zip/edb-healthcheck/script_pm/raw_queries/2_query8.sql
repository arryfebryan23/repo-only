select 
  schemaname, 
  relname, 
  idx_scan :: float /(seq_scan + idx_scan) fraction_of_index_scans, 
  idx_scan, 
  seq_scan 
from 
  pg_stat_all_tables 
where 
  seq_scan + idx_scan != 0 
order by 
  seq_scan desc 
limit 
  10;
