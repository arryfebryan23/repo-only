SELECT 
  db.datname database_name, 
  pg_size_pretty(
    pg_database_size(db.oid)
  ) database_size 
FROM
  pg_database db;
