select 
  datname database_name, 
  blks_hit 
from 
  pg_stat_database;
