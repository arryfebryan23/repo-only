SELECT 
  name, 
  setting 
FROM 
  pg_settings 
WHERE 
  name ~ 'vacuum' 
  AND name ~ '_age$' 
ORDER BY 
  1 ASC;

SELECT 
  datname, 
  age(datfrozenxid), 
  (
    age(datfrozenxid):: numeric / 1000000000 * 100
  ):: numeric(4, 2) as "% WRAPAROUND RISK" 
FROM 
  pg_database 
ORDER BY 
  2 DESC;

SELECT 
  x.schema_name, 
  x.table_name, 
  x."TXID age", 
  x."% WRAPAROUND RISK" 
FROM 
  (
    SELECT 
      n.nspname as schema_name, 
      c.oid :: regclass as table_name, 
      greatest(
        age(c.relfrozenxid), 
        age(t.relfrozenxid)
      ) as "TXID age", 
      (
        greatest(
          age(c.relfrozenxid), 
          age(t.relfrozenxid)
        ):: numeric / 1000000000 * 100
      ):: numeric(4, 2) as "% WRAPAROUND RISK" 
    FROM 
      pg_class c 
      JOIN pg_namespace n on c.relnamespace = n.oid 
      LEFT JOIN pg_class t ON c.reltoastrelid = t.oid 
    WHERE 
      c.relkind IN ('r', 'm')
  ) as x 
WHERE 
  x."TXID age" IS NOT NULL 
ORDER BY 
  3 DESC;
