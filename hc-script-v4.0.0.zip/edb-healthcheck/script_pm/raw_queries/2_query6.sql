select 
  schemaname, 
  tablename, 
  pg_size_pretty(size_1) total_table_size 
from 
  (
    select 
      schemaname, 
      tablename, 
      pg_total_relation_size(
        '"' || schemaname || '"."' || tablename || '"'
      ) size_1 
    from 
      pg_tables 
    order by 
      size_1 desc 
    limit 
      5
  ) as x;
