SELECT * FROM pg_stat_bgwriter;

WITH 
  io_stats AS (
    SELECT 
      100 *(
        buffers_clean :: float /(
          buffers_checkpoint :: float + buffers_clean :: float + buffers_backend :: float
        )
      ) bgwriter_pct, 
      100 *(
        buffers_checkpoint :: float /(
          buffers_checkpoint :: float + buffers_clean :: float + buffers_backend :: float
        )
      ) checkpoint_pct 
    FROM 
      pg_stat_bgwriter
  ) 
SELECT 
  bgwriter_pct, 
  checkpoint_pct, 
  100 - bgwriter_pct - checkpoint_pct as backend_pct 
FROM 
  io_stats;
