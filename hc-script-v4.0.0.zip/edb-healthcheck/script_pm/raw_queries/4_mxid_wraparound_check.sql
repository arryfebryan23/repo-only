SELECT 
  datname, 
  mxid_age(datminmxid) 
FROM 
  pg_database 
WHERE 
  mxid_age(datminmxid) > current_setting(
    'autovacuum_multixact_freeze_max_age'
  ):: bigint 
ORDER BY 
  2 DESC;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass AS table_name, 
  c.relminmxid as table_mxid, 
  mxid_age(c.relminmxid) as age_of_table_mxid, 
  pg_size_pretty(
    pg_total_relation_size(c.oid)
  ) AS table_total_size 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  c.relkind IN ('r', 'm', 't') 
  AND mxid_age(c.relminmxid) > current_setting(
    'autovacuum_multixact_freeze_max_age'
  ):: bigint 
ORDER BY 
  4 DESC;

SELECT 
  2 ^ 31 - max(
    mxid_age(datminmxid)
  ) AS mxid_left 
FROM 
  pg_database;

SELECT 
  n.nspname as schema_name, 
  c.oid :: regclass AS table_name, 
  c.relminmxid as table_mxid, 
  mxid_age(c.relminmxid) as age_of_table_mxid, 
  current_setting(
    'autovacuum_multixact_freeze_max_age'
  ):: bigint - mxid_age(c.relminmxid) AS xid_left_to_antifreeze, 
  pg_size_pretty(
    pg_total_relation_size(c.oid)
  ) AS table_total_size 
FROM 
  pg_class c 
  JOIN pg_namespace n on c.relnamespace = n.oid 
WHERE 
  c.relkind IN ('r', 'm', 't') 
ORDER BY 
  4 DESC;
