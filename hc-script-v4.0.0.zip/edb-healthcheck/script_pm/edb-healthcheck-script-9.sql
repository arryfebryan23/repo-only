\c database-name

set search_path to schema-list;

--- 1 ---
\! rm -rf /path/to/edb-healthcheck/edb-results/1_db_ukuran.txt
\o /path/to/edb-healthcheck/edb-results/1_db_ukuran.txt
\i /path/to/edb-healthcheck/raw_queries/1_db_ukuran.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/1_db_uptime.txt
\o /path/to/edb-healthcheck/edb-results/1_db_uptime.txt
\i /path/to/edb-healthcheck/raw_queries/1_db_uptime.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/1_showall.txt
\o /path/to/edb-healthcheck/edb-results/1_showall.txt
\i /path/to/edb-healthcheck/raw_queries/1_showall.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/1_version.txt
\o /path/to/edb-healthcheck/edb-results/1_version.txt
\i /path/to/edb-healthcheck/raw_queries/1_version.sql
--- 1 ---

--- 2 ---
\! rm -rf /path/to/edb-healthcheck/edb-results/2_blk_hit_ratio.txt
\o /path/to/edb-healthcheck/edb-results/2_blk_hit_ratio.txt
\i /path/to/edb-healthcheck/raw_queries/2_blk_hit_ratio.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_bloat_table.txt
\o /path/to/edb-healthcheck/edb-results/2_bloat_table.txt
\i /path/to/edb-healthcheck/raw_queries/2_bloat_table.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_buffers_checkpoint.txt
\o /path/to/edb-healthcheck/edb-results/2_buffers_checkpoint.txt
\i /path/to/edb-healthcheck/raw_queries/2_buffers_checkpoint.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_commit_ratio.txt
\o /path/to/edb-healthcheck/edb-results/2_commit_ratio.txt
\i /path/to/edb-healthcheck/raw_queries/2_commit_ratio.sql

--\! rm -rf /path/to/edb-healthcheck/edb-results/2_db_size.txt
--\o /path/to/edb-healthcheck/edb-results/2_db_size.txt
--\i /path/to/edb-healthcheck/raw_queries/2_db_size.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_dml_activity.txt
\o /path/to/edb-healthcheck/edb-results/2_dml_activity.txt
\i /path/to/edb-healthcheck/raw_queries/2_dml_activity.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_duplicate_index.txt
\o /path/to/edb-healthcheck/edb-results/2_duplicate_index.txt
\i /path/to/edb-healthcheck/raw_queries/2_duplicate_index.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_history_vacuum_analyze.txt
\o /path/to/edb-healthcheck/edb-results/2_history_vacuum_analyze.txt
\i /path/to/edb-healthcheck/raw_queries/2_history_vacuum_analyze.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_index_size.txt
\o /path/to/edb-healthcheck/edb-results/2_index_size.txt
\i /path/to/edb-healthcheck/raw_queries/2_index_size.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query1.txt
\o /path/to/edb-healthcheck/edb-results/2_query1.txt
\i /path/to/edb-healthcheck/raw_queries/2_query1.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query10.txt
\o /path/to/edb-healthcheck/edb-results/2_query10.txt
\i /path/to/edb-healthcheck/raw_queries/2_query10.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query11.txt
\o /path/to/edb-healthcheck/edb-results/2_query11.txt
\i /path/to/edb-healthcheck/raw_queries/2_query11.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query12.txt
\o /path/to/edb-healthcheck/edb-results/2_query12.txt
\i /path/to/edb-healthcheck/raw_queries/2_query12.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query13.txt
\o /path/to/edb-healthcheck/edb-results/2_query13.txt
\i /path/to/edb-healthcheck/raw_queries/2_query13.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query14.txt
\o /path/to/edb-healthcheck/edb-results/2_query14.txt
\i /path/to/edb-healthcheck/raw_queries/2_query14.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query15.txt
\o /path/to/edb-healthcheck/edb-results/2_query15.txt
\i /path/to/edb-healthcheck/raw_queries/2_query15.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query16.txt
\o /path/to/edb-healthcheck/edb-results/2_query16.txt
\i /path/to/edb-healthcheck/raw_queries/2_query16.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query2.txt
\o /path/to/edb-healthcheck/edb-results/2_query2.txt
\i /path/to/edb-healthcheck/raw_queries/2_query2.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query3.txt
\o /path/to/edb-healthcheck/edb-results/2_query3.txt
\i /path/to/edb-healthcheck/raw_queries/2_query3.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query4.txt
\o /path/to/edb-healthcheck/edb-results/2_query4.txt
\i /path/to/edb-healthcheck/raw_queries/2_query4.sql

--\! rm -rf /path/to/edb-healthcheck/edb-results/2_query5.txt
--\o /path/to/edb-healthcheck/edb-results/2_query5.txt
--\i /path/to/edb-healthcheck/raw_queries/2_query5.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query6.txt
\o /path/to/edb-healthcheck/edb-results/2_query6.txt
\i /path/to/edb-healthcheck/raw_queries/2_query6.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query7.txt
\o /path/to/edb-healthcheck/edb-results/2_query7.txt
\i /path/to/edb-healthcheck/raw_queries/2_query7.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query8.txt
\o /path/to/edb-healthcheck/edb-results/2_query8.txt
\i /path/to/edb-healthcheck/raw_queries/2_query8.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_query9.txt
\o /path/to/edb-healthcheck/edb-results/2_query9.txt
\i /path/to/edb-healthcheck/raw_queries/2_query9.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_table_need_vacuum.txt
\o /path/to/edb-healthcheck/edb-results/2_table_need_vacuum.txt
\i /path/to/edb-healthcheck/raw_queries/2_table_need_vacuum.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_top_table_seq_scan.txt
\o /path/to/edb-healthcheck/edb-results/2_top_table_seq_scan.txt
\i /path/to/edb-healthcheck/raw_queries/2_top_table_seq_scan.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_top_table_size.txt
\o /path/to/edb-healthcheck/edb-results/2_top_table_size.txt
\i /path/to/edb-healthcheck/raw_queries/2_top_table_size.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/2_unused_index.txt
\o /path/to/edb-healthcheck/edb-results/2_unused_index.txt
\i /path/to/edb-healthcheck/raw_queries/2_unused_index.sql
--- 2 ---

--- 3 ---
\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_database.txt
\o /path/to/edb-healthcheck/edb-results/3_list_database.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_database.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_extension.txt
\o /path/to/edb-healthcheck/edb-results/3_list_extension.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_extension.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_function.txt
\o /path/to/edb-healthcheck/edb-results/3_list_function.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_function.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_index.txt
\o /path/to/edb-healthcheck/edb-results/3_list_index.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_index.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_role.txt
\o /path/to/edb-healthcheck/edb-results/3_list_role.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_role.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_schema.txt
\o /path/to/edb-healthcheck/edb-results/3_list_schema.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_schema.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_sequence.txt
\o /path/to/edb-healthcheck/edb-results/3_list_sequence.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_sequence.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_table.txt
\o /path/to/edb-healthcheck/edb-results/3_list_table.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_table.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/3_list_tablespace.txt
\o /path/to/edb-healthcheck/edb-results/3_list_tablespace.txt
\i /path/to/edb-healthcheck/raw_queries/3_list_tablespace.sql
--- 3 ---

--- 4 ---
\! rm -rf /path/to/edb-healthcheck/edb-results/4_check_activity.txt
\o /path/to/edb-healthcheck/edb-results/4_check_activity.txt
\i /path/to/edb-healthcheck/raw_queries/4_check_activity.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_check_locking_9.txt
\o /path/to/edb-healthcheck/edb-results/4_check_locking_9.txt
\i /path/to/edb-healthcheck/raw_queries/4_check_locking_9.sql

--\! rm -rf /path/to/edb-healthcheck/edb-results/4_check_temp_files.txt
--\o /path/to/edb-healthcheck/edb-results/4_check_temp_files.txt
--\i /path/to/edb-healthcheck/raw_queries/4_check_temp_files.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_fdw_servers.txt
\o /path/to/edb-healthcheck/edb-results/4_fdw_servers.txt
\i /path/to/edb-healthcheck/raw_queries/4_fdw_servers.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_idle_long_running_query.txt
\o /path/to/edb-healthcheck/edb-results/4_idle_long_running_query.txt
\i /path/to/edb-healthcheck/raw_queries/4_idle_long_running_query.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_keyword_object_check.txt
\o /path/to/edb-healthcheck/edb-results/4_keyword_object_check.txt
\i /path/to/edb-healthcheck/raw_queries/4_keyword_object_check.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_long_running_query.txt
\o /path/to/edb-healthcheck/edb-results/4_long_running_query.txt
\i /path/to/edb-healthcheck/raw_queries/4_long_running_query.sql

--\! rm -rf /path/to/edb-healthcheck/edb-results/4_mxid_wraparound_check.txt
--\o /path/to/edb-healthcheck/edb-results/4_mxid_wraparound_check.txt
--\i /path/to/edb-healthcheck/raw_queries/4_mxid_wraparound_check.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_primary_key_check.txt
\o /path/to/edb-healthcheck/edb-results/4_primary_key_check.txt
\i /path/to/edb-healthcheck/raw_queries/4_primary_key_check.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_replication_slots_9.txt
\o /path/to/edb-healthcheck/edb-results/4_replication_slots_9.txt
\i /path/to/edb-healthcheck/raw_queries/4_replication_slots_9.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_settings_and_hba.txt
\o /path/to/edb-healthcheck/edb-results/4_settings_and_hba.txt
\i /path/to/edb-healthcheck/raw_queries/4_settings_and_hba.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_table_without_pk_uk.txt
\o /path/to/edb-healthcheck/edb-results/4_table_without_pk_uk.txt
\i /path/to/edb-healthcheck/raw_queries/4_table_without_pk_uk.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v1.txt
\o /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v1.txt
\i /path/to/edb-healthcheck/raw_queries/4_txid_wraparound_check_v1.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v2_9.txt
\o /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v2_9.txt
\i /path/to/edb-healthcheck/raw_queries/4_txid_wraparound_check_v2_9.sql

\! rm -rf /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v3.txt
\o /path/to/edb-healthcheck/edb-results/4_txid_wraparound_check_v3.txt
\i /path/to/edb-healthcheck/raw_queries/4_txid_wraparound_check_v3.sql
--- 4 ---
